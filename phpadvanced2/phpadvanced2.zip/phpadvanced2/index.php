<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="checkers.css">
</head>
<body>
<table>


	<tr>
		<td class="red"></td>
		<td class="black"></td>
		<td class="red"></td>
		<td class="black"></td>
		<td class="red"></td>
		<td class="black"></td>
		<td class="red"></td>
		<td class="black"></td>
	</tr>
	<tr>
		<td class="black"></td>
		<td class="red"></td>
		<td class="black"></td>
		<td class="red"></td>
		<td class="black"></td>
		<td class="red"></td>
		<td class="black"></td>
		<td class="red"></td>
	</tr>
	<tr>
		<td class="red"></td>
		<td class="black"></td>
		<td class="red"></td>
		<td class="black"></td>
		<td class="red"></td>
		<td class="black"></td>
		<td class="red"></td>
		<td class="black"></td>
	</tr>
	<tr>
		<td class="black"></td>
		<td class="red"></td>
		<td class="black"></td>
		<td class="red"></td>
		<td class="black"></td>
		<td class="red"></td>
		<td class="black"></td>
		<td class="red"></td>
	</tr>


</table>
</body>
</html>